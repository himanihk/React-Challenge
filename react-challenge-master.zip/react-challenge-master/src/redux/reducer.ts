export const reducer = (initialState = {}, action) => {
  switch (action.type) {
    default:
      return initialState
  }
}
