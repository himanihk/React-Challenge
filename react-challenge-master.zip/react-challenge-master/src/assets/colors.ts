// Color names provided by colorhexa.com
const colors = {
  black: '#000000',
  darkLimeGreen: '#64A364',
  lightGrayishLimeGreen: '#e9f9ea',
  mostlyWhiteGrey: '#f7f7f7',
  softRed: '#ee4957',
  veryLightGray: '#e5e5e5',
  veryDarkGrayishBlue: '#44484c',
  veryPaleRed: '#ffe4e4',
  vividRed: '#f20505',
  white: '#ffffff',
}

export { colors }
