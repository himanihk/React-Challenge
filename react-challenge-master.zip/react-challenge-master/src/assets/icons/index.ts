const arrowIcon = require('./arrow-icon.png')
const redHeartIcon = require('./red-heart-icon.png')
const searchIcon = require('./search-icon.png')
const whiteHeartIcon = require('./white-heart-icon.png')

const icons = {
  arrowIcon,
  redHeartIcon,
  searchIcon,
  whiteHeartIcon,
}

export { icons }
