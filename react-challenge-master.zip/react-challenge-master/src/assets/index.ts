import { colors } from './colors'
import { icons } from './icons'

export { colors, icons }
